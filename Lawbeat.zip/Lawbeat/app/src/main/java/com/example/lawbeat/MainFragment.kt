package com.example.lawbeat


import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*


class MainFragment : Fragment() {
    lateinit var rvMain: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view:View =  inflater.inflate(R.layout.fragment_main, container, false)
        rvMain = view.findViewById(R.id.recview)
        rvMain.layoutManager = LinearLayoutManager(context)
        rvMain.adapter = RvAdapter()
        return view;
    }
    internal class RowHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    internal class AdHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    internal class RvAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return if (viewType == 0) {
                val view: View =
                    LayoutInflater.from(parent.context).inflate(R.layout.row_first, parent, false)
                AdHolder(view)
            } else {
                val view: View =
                    LayoutInflater.from(parent.context).inflate(R.layout.row_default, parent, false)
                RowHolder(view)
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {}
        override fun getItemViewType(position: Int): Int {
            return if (position == 0) 0 else 1
        }

        override fun getItemCount(): Int {
            return 10
        }
    }
}



